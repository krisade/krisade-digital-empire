# KRISADE DIGITAL EMPIRE Website

A responsive, static business website built with HTML, CSS and JavaScript.

## Files
- `index.html` — website content and structure
- `styles.css` — layout, colours and responsive styling
- `script.js` — mobile navigation and current footer year

## Preview locally
Open `index.html` in a web browser.

## Publish free with GitHub Pages
1. Sign in to GitHub and create a new **public** repository, for example `krisade-website`.
2. Upload `index.html`, `styles.css` and `script.js` to the repository's main/root folder.
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then save.
6. Wait for GitHub Pages to publish the site. The address will look like `https://YOUR-USERNAME.github.io/krisade-website/`.

## Before publishing
- Confirm that the phone number, email, address and social handles are still correct.
- Add your official company logo and real product photographs if you want them displayed.
- This first version is an information and enquiry website. It does not yet process online payments, stock management or customer orders.
- Google Fonts are loaded from the internet; the page still has fallback fonts if they are unavailable.
